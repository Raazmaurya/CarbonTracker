# Carbon Emissions Tracker
Calculates carbon emissions based on battery usage, car travel, and other factors. Information is displayed to user, promoting environmental-consciousness
