package com.example.yangy.carbonfootprint;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;

//extends IntentService??
public class PhoneUsageBackground {


}
